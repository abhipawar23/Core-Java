package com.homework.hasa.relation;

import java.io.Serializable;

public class Department implements Serializable {

	private String deptname;

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
}
