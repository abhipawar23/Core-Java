package com.homework.isa.relation;

import java.io.Serializable;

public class Student implements Serializable {

	int sId;
	String Sname;

	public Student(int sId, String sname) {
		this.sId = sId;
		Sname = sname;
	}

}
